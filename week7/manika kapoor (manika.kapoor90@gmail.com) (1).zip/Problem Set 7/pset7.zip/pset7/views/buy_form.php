<div>
        <form action="buy.php" method="post">
            <fieldset>
                <div class="form-group">
                    <input autocomplete="off" autofocus class="form-control" name="buy_stock" placeholder="Stock symbol to buy" type="text"/>
                </div>
                <div class="form-group">
                    <input autocomplete="off" autofocus class="form-control" name="buy_amount" placeholder="Amount to buy" type="number"/>
                </div>
                <div class="form-group">
                    <button class="btn btn-default" type="submit">
                        <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                        Submit
                    </button>
                </div>
            </fieldset>
        </form>
    <div>
        or <a href="index.php">go back to portfolio</a>
    </div>

