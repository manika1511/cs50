<form action="deposit.php" method="post">
    <fieldset>
        <div class="control-group">
            <input class="input-medium" name="deposit" placeholder="Deposit Amount" type="text"/>
        </div>
        <div class="control-group">
            <button type="submit" class="btn">Deposit</button>
        </div>
    </fieldset>
</form>