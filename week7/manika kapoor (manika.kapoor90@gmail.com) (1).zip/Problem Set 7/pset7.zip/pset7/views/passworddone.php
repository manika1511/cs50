<?php
    // The message displayed when you change your password
    print("Your password has been changed successfully.");
?>